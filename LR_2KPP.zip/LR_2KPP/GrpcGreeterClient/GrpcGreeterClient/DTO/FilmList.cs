﻿using FlatSharp.Attributes;
using System.Collections.Generic;

namespace GrpcGreeterClient.DTO
{
    [FlatBufferTable]
    public class FilmList
    {
        [FlatBufferItem(0, SortedVector = true)]
        public virtual IList<FilmModel> Films { get; set; } = new List<FilmModel>();
    }
}
