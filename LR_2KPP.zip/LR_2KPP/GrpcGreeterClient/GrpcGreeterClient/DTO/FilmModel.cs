﻿using FlatSharp.Attributes;

namespace GrpcGreeterClient.DTO
{
    [FlatBufferTable]
    public class FilmModel
    {
        [FlatBufferItem(0, Key = true)]
        public virtual string Id { get; set; }
        [FlatBufferItem(1)]
        public virtual string Name { get; set; }
        [FlatBufferItem(2)]
        public virtual string Title { get; set; }
    }
}
