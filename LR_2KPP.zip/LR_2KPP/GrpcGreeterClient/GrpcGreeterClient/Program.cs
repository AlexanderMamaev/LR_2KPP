﻿using FlatSharp;
using gRPC;
using Grpc.Net.Client;
using GrpcGreeterClient.DTO;
using Newtonsoft.Json;
using System;
using System.Text;
using System.Threading.Tasks;

namespace GrpcGreeterClient
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // The port number(5001) must match the port of the gRPC server.
            Console.WriteLine("Enter port and format (json or xml):");
            string formatAndPort = Console.ReadLine();
            while (true)
            {
                Console.WriteLine("Enter command:");
                string[] command = Console.ReadLine().Split(' ');

                var channel = GrpcChannel.ForAddress("https://localhost:5001");
                var client = new Greeter.GreeterClient(channel);

                if (String.Equals(command[0], "get_films"))
                {
                    var getFilms = await client.GetFilmsAsync(
                                      new GetFilmsRequest());

                    byte[] data = System.Convert.FromBase64String(getFilms.Data);
                    FilmList parsedList = FlatBufferSerializer.Default.Parse<FilmList>(data);

                    var json = JsonConvert.SerializeObject(parsedList, Newtonsoft.Json.Formatting.Indented);
                    Console.WriteLine("Get film list: " + json);
                }
                if (String.Equals(command[0], "get_ticket"))
                {
                    var getTicket = await client.GetTicketAsync(
                                      new TicketRequest { IdFilms = command[1]});

                    Console.WriteLine("Id ticket: " + getTicket.IdTicket);
                    Console.WriteLine("Name film: " + getTicket.NameFilm);
                }
                if (String.Equals(command[0], "exit"))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Available command:");
                    Console.WriteLine("exit");
                    Console.WriteLine("get_ticket + {Id Film}");
                    Console.WriteLine("get_films");
                }
            }
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
