﻿using FlatSharp;
using gRPC.DTO;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace gRPC.Services
{
    public static class FilmService
    {
        public static String GetFilms()
        {
            FilmList filmList = new FilmList();

            List<FilmModel> films = JsonConvert.DeserializeObject<List<FilmModel>>(File.ReadAllText(@"C:\Users\User\Desktop\gRPC\gRPC\Resources\films.json"));

            foreach(FilmModel film in films)
            {
                filmList.Films.Add(film);
            }

            byte[] data = new byte[FlatBufferSerializer.Default.GetMaxSize<FilmList>(filmList)];
            int bytesWritten = FlatBufferSerializer.Default.Serialize(filmList, data);

            return System.Convert.ToBase64String(data);
        }

        public static TicketReplay GetTicket(string idTicket)
        {
            FilmList filmList = new FilmList();

            List<FilmModel> films = JsonConvert.DeserializeObject<List<FilmModel>>(File.ReadAllText(@"C:\Users\User\Desktop\gRPC\gRPC\Resources\films.json"));

            foreach (FilmModel film in films)
            {
                filmList.Films.Add(film);
            }

            byte[] data = new byte[FlatBufferSerializer.Default.GetMaxSize<FilmList>(filmList)];
            int bytesWritten = FlatBufferSerializer.Default.Serialize(filmList, data);
            FilmList parsedList = FlatBufferSerializer.Default.Parse<FilmList>(data);

            FilmModel existedFilm = parsedList.Films.BinarySearchByFlatBufferKey(idTicket);

            TicketReplay ticket = new TicketReplay();
            if(existedFilm != null)
            {
                ticket.IdTicket = Guid.NewGuid().ToString();
                ticket.NameFilm = existedFilm?.Name;
            }
            else
            {
                ticket.IdTicket = "Sorry This films is not exist!";
            }

            return ticket;
        }
    }
}
