using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using gRPC.Services;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace gRPC
{
    public class GreeterService : Greeter.GreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
        {
            return Task.FromResult(new HelloReply
            {
                Message = "Hello " + request.Name
            });
        }

        public override Task<GetFilmsReplay> GetFilms(GetFilmsRequest request, ServerCallContext context)
        {
            _logger.LogInformation($"Getting films");
            return Task.FromResult(new GetFilmsReplay
            {
                Data = FilmService.GetFilms()
            });
        }

        public override Task<TicketReplay> GetTicket(TicketRequest request, ServerCallContext context)
        {
            _logger.LogInformation($"Getting ticket");
            return Task.FromResult(FilmService.GetTicket(request.IdFilms));
        }
    }
}
