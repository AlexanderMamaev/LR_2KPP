﻿using FlatSharp.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace gRPC.DTO
{
    [FlatBufferTable]
    public class FilmModel
    {
        [FlatBufferItem(0, Key = true)]
        public virtual string Id { get; set; }
        [FlatBufferItem(1)]
        public virtual string Name { get; set; }
        [FlatBufferItem(2)]
        public virtual string Title { get; set; }
    }
}
